/** Automatically generated file. DO NOT MODIFY */
package com.manish.tabdemo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}